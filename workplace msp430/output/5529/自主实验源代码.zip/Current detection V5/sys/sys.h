/*
 * sys.h
 *
 *  Created on: 2020��8��30��
 *      Author: DELL
 */

#ifndef SYS_SYS_H_
#define SYS_SYS_H_


void Init_20MHz_MCLK();


#endif /* SYS_SYS_H_ */
