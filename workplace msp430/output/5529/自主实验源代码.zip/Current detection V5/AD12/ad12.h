/*
 * adc12.h
 *
 *  Created on: 2020��9��2��
 *      Author: DELL
 */

#ifndef AD12_AD12_H_
#define AD12_AD12_H_

#define FFT_N     128

unsigned int AD_capture(void);
void Init_AD(void);

extern struct complex h[128];
extern unsigned char fft_flag;


#endif /* AD12_AD12_H_ */
